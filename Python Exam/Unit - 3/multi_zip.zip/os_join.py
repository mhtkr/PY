import os
path = os.path.join('folder1', 'folder2', 'file.txt')
print(path)